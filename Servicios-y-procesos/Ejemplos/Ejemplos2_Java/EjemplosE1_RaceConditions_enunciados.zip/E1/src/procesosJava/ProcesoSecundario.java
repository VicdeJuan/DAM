package procesosJava;

public class ProcesoSecundario {

	public static void main(String[] args) {
		System.out.println("Proceso Secundario...");
		System.exit(103);
	}

}
